# TD-W03 单/多 Agent 公平实验 / critic / v1.0.0

质疑候选是否把局部绿色当整体通过、把同源模型自评当独立 Oracle、把缺失证据当空成功、在权限检查前允许写副作用、删除断言、放宽权限或用更多预算制造优势。故障 multi-agent arm receives twice the token budget 必须保持 FAIL；否则拒绝候选。
